package com.the3linecard.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class The3LineCard {

	public static void main(String[] args) {
		SpringApplication.run(The3LineCard.class, args);
	}

}
