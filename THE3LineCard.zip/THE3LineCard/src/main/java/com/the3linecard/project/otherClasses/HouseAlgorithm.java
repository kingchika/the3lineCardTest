package com.the3linecard.project.otherClasses;

public class HouseAlgorithm {
	

	// n = 2;
	// m = 8;
   // for(int i = 0; i < n ; i++) {
   //    for(int j = 1; j <= m ; j++){
   //       if(j == 1) { get r = array[j+1]
   //           if r = 0 then array[j] = 0
   //           else    array[j] = 1    }
  //        else if(j == m){  get r = array[j - 1]
  //               if r = 0 then array[j] = 0 
 //                else  array[j] = 1
 //         else  
//	             get t = array[j - 1]
//               get s = array[j + 1]
//                  if t = 0 Or s = 0
//	                       array[j]  = 0
//               else 
//                     array[j] = 1
//            end inner loop of j
//        end inner loop of i	
}
